# WordPress MySQL database migration
#
# Generated: Tuesday 2. January 2018 05:38 UTC
# Hostname: localhost
# Database: `test_db`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_lockdowns`
#

DROP TABLE IF EXISTS `wp_lockdowns`;


#
# Table structure of table `wp_lockdowns`
#

CREATE TABLE `wp_lockdowns` (
  `lockdown_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `release_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lockdown_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`lockdown_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_lockdowns`
#

#
# End of data contents of table `wp_lockdowns`
# --------------------------------------------------------



#
# Delete any existing table `wp_login_fails`
#

DROP TABLE IF EXISTS `wp_login_fails`;


#
# Table structure of table `wp_login_fails`
#

CREATE TABLE `wp_login_fails` (
  `login_attempt_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `login_attempt_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_IP` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`login_attempt_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_login_fails`
#

#
# End of data contents of table `wp_login_fails`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/', 'yes'),
(2, 'home', 'http://localhost/', 'yes'),
(3, 'blogname', 'Site Name', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'bdiaz@bdgfx.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:37:"acf-options-page/acf-options-page.php";i:1;s:29:"acf-repeater/acf-repeater.php";i:2;s:30:"advanced-custom-fields/acf.php";i:3;s:45:"enable-media-replace/enable-media-replace.php";i:4;s:32:"login-lockdown/loginlockdown.php";i:5;s:60:"quick-pagepost-redirect-plugin/page_post_redirect_plugin.php";i:6;s:69:"simple-301-redirects-addon-bulk-uploader/simple-301-bulk-uploader.php";i:7;s:48:"simple-301-redirects/wp-simple-301-redirects.php";i:8;s:45:"simple-page-ordering/simple-page-ordering.php";i:10;s:32:"wp-sync-db-master/wp-sync-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'bd-theme', 'yes'),
(41, 'stylesheet', 'bd-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'cron', 'a:4:{i:1514911230;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1514954442;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1514954898;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(119, 'can_compress_scripts', '1', 'no'),
(134, 'recently_activated', 'a:1:{s:23:"wordfence/wordfence.php";i:1514868797;}', 'yes'),
(136, 'loginlockdownAdminOptions', 'a:6:{s:17:"max_login_retries";i:3;s:14:"retries_within";i:5;s:14:"lockout_length";i:60;s:25:"lockout_invalid_usernames";s:2:"no";s:17:"mask_login_errors";s:2:"no";s:16:"show_credit_link";s:3:"yes";}', 'yes'),
(137, 'loginlockdown_db_version', '1.0', 'no'),
(138, 'wpsdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"tbY+DqPZ0S+xHGI2Fb0vd3fB4em7xVEy";s:10:"allow_pull";b:0;s:10:"allow_push";b:0;s:8:"profiles";a:1:{i:0;a:18:{s:13:"save_computer";s:1:"1";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"0";s:18:"exclude_post_types";s:1:"0";s:6:"action";s:8:"savefile";s:15:"connection_info";s:0:"";s:11:"replace_old";a:0:{}s:11:"replace_new";a:0:{}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:18:"exclude_transients";s:1:"1";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:1:"0";s:18:"create_new_profile";s:0:"";s:4:"name";s:9:"localhost";}}s:10:"verify_ssl";b:0;s:17:"blacklist_plugins";a:0:{}}', 'yes'),
(139, 'acf_version', '4.4.12', 'yes'),
(140, 'ppr_version', '5.1.8', 'yes'),
(141, 'loginlockdownmsrunonce', 'done', 'no'),
(142, 'wpe_settings', '', 'yes'),
(146, 'wordfence_version', '6.3.22', 'yes'),
(147, 'wordfenceActivated', '0', 'yes'),
(148, 'wf_plugin_act_error', '', 'yes'),
(152, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1514868938;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(153, 'current_theme', '', 'yes'),
(154, 'theme_mods_bd-theme', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(155, 'theme_switched', '', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(9, 6, '_edit_last', '1'),
(10, 6, '_edit_lock', '1514868361:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(3, 1, '2018-01-02 04:40:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-01-02 04:40:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=3', 0, 'post', '', 0),
(6, 1, '2018-01-02 04:48:23', '2018-01-02 04:48:23', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-01-02 04:48:23', '2018-01-02 04:48:23', '', 0, 'http://localhost/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-01-02 04:48:23', '2018-01-02 04:48:23', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-01-02 04:48:23', '2018-01-02 04:48:23', '', 6, 'http://localhost/2018/01/02/6-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'brandond424'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:3:{s:64:"2ad915261a3f0c10a84a4d30d01db8e2c2af88926ce2fb7ee705cd07140204b8";a:4:{s:10:"expiration";i:1515040837;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1514868037;}s:64:"fff29802854508f575d5131f4506d0baef1dd5e38740ef1a5630abfa6b600737";a:4:{s:10:"expiration";i:1515041175;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1514868375;}s:64:"417afb6a5bc9664e9281e60f68008ae824bd9254ad7131db94fc6c3852da086a";a:4:{s:10:"expiration";i:1515041287;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36";s:5:"login";i:1514868487;}}'),
(17, 1, 'wp_user-settings', 'mfold=o&libraryContent=browse&editor=html'),
(18, 1, 'wp_user-settings-time', '1514868033'),
(19, 1, 'wp_dashboard_quick_press_last_post_id', '3'),
(20, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'brandond424', '$P$BLps/bxJUya2Y9t09.b/yBCridCHf3.', 'brandond424', 'bdiaz@bdgfx.com', '', '2018-01-02 04:40:30', '', 0, 'brandond424') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfBadLeechers`
#

DROP TABLE IF EXISTS `wp_wfBadLeechers`;


#
# Table structure of table `wp_wfBadLeechers`
#

CREATE TABLE `wp_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfBadLeechers`
#

#
# End of data contents of table `wp_wfBadLeechers`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfBlockedCommentLog`
#

DROP TABLE IF EXISTS `wp_wfBlockedCommentLog`;


#
# Table structure of table `wp_wfBlockedCommentLog`
#

CREATE TABLE `wp_wfBlockedCommentLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  `blockType` varchar(50) NOT NULL DEFAULT 'gsb',
  PRIMARY KEY (`IP`,`unixday`,`blockType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfBlockedCommentLog`
#

#
# End of data contents of table `wp_wfBlockedCommentLog`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfBlockedIPLog`
#

DROP TABLE IF EXISTS `wp_wfBlockedIPLog`;


#
# Table structure of table `wp_wfBlockedIPLog`
#

CREATE TABLE `wp_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  `blockType` varchar(50) NOT NULL DEFAULT 'generic',
  PRIMARY KEY (`IP`,`unixday`,`blockType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfBlockedIPLog`
#

#
# End of data contents of table `wp_wfBlockedIPLog`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfBlocks`
#

DROP TABLE IF EXISTS `wp_wfBlocks`;


#
# Table structure of table `wp_wfBlocks`
#

CREATE TABLE `wp_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfBlocks`
#

#
# End of data contents of table `wp_wfBlocks`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfBlocksAdv`
#

DROP TABLE IF EXISTS `wp_wfBlocksAdv`;


#
# Table structure of table `wp_wfBlocksAdv`
#

CREATE TABLE `wp_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfBlocksAdv`
#

#
# End of data contents of table `wp_wfBlocksAdv`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfConfig`
#

DROP TABLE IF EXISTS `wp_wfConfig`;


#
# Table structure of table `wp_wfConfig`
#

CREATE TABLE `wp_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  `autoload` enum('no','yes') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfConfig`
#
INSERT INTO `wp_wfConfig` ( `name`, `val`, `autoload`) VALUES
('actUpdateInterval', '', 'yes'),
('addCacheComment', '0', 'yes'),
('adminUserList', 'b:0;', 'yes'),
('advancedCommentScanning', '0', 'yes'),
('ajaxWatcherDisabled_admin', '0', 'yes'),
('ajaxWatcherDisabled_front', '0', 'yes'),
('alertEmails', '', 'yes'),
('alertOn_adminLogin', '1', 'yes'),
('alertOn_block', '1', 'yes'),
('alertOn_critical', '1', 'yes'),
('alertOn_firstAdminLoginOnly', '0', 'yes'),
('alertOn_firstNonAdminLoginOnly', '0', 'yes'),
('alertOn_loginLockout', '1', 'yes'),
('alertOn_lostPasswdForm', '1', 'yes'),
('alertOn_nonAdminLogin', '0', 'yes'),
('alertOn_throttle', '0', 'yes'),
('alertOn_update', '0', 'yes'),
('alertOn_warnings', '1', 'yes'),
('alertOn_wordfenceDeactivated', '1', 'yes'),
('alert_maxHourly', '0', 'yes'),
('allowed404s', '/favicon.ico\n/apple-touch-icon*.png\n/*@2x.png\n/browserconfig.xml', 'yes'),
('allowed404s6116Migration', '1', 'yes'),
('allowHTTPSCaching', '0', 'yes'),
('allScansScheduled', 'a:0:{}', 'yes'),
('apiKey', '190e49763a74caca345970384c7d80285777097237cc71838de79c206a8234cc8ecdf45e451d9b65db473ef8e4f149886e2c9fb56f8ffb83d60cd99b6123592a', 'yes'),
('autoBlockScanners', '1', 'yes'),
('autoUpdate', '0', 'yes'),
('bannedURLs', '', 'yes'),
('betaThreatDefenseFeed', '0', 'yes'),
('blockedTime', '300', 'yes'),
('blockFakeBots', '0', 'yes'),
('cacheType', 'disabled', 'yes'),
('cbl_action', 'block', 'yes'),
('cbl_bypassRedirDest', '', 'yes'),
('cbl_bypassRedirURL', '', 'yes'),
('cbl_bypassViewURL', '', 'yes'),
('cbl_cookieVal', '5a4b102ae31da', 'yes'),
('cbl_countries', '', 'yes'),
('cbl_loggedInBlocked', '0', 'yes'),
('cbl_loginFormBlocked', '0', 'yes'),
('cbl_redirURL', '', 'yes'),
('cbl_restOfSiteBlocked', '1', 'yes'),
('checkSpamIP', '0', 'yes'),
('currentCronKey', '', 'yes'),
('dashboardData', 'a:4:{s:9:"generated";i:1514867567;s:3:"tdf";a:3:{s:9:"community";i:5237;s:7:"premium";i:5295;s:9:"blacklist";i:2411;}s:10:"attackdata";a:3:{s:3:"24h";a:24:{i:0;a:2:{s:1:"t";i:1514779200;s:1:"c";i:846675;}i:1;a:2:{s:1:"t";i:1514782800;s:1:"c";i:834075;}i:2;a:2:{s:1:"t";i:1514786400;s:1:"c";i:817372;}i:3;a:2:{s:1:"t";i:1514790000;s:1:"c";i:876790;}i:4;a:2:{s:1:"t";i:1514793600;s:1:"c";i:850000;}i:5;a:2:{s:1:"t";i:1514797200;s:1:"c";i:900383;}i:6;a:2:{s:1:"t";i:1514800800;s:1:"c";i:946881;}i:7;a:2:{s:1:"t";i:1514804400;s:1:"c";i:951437;}i:8;a:2:{s:1:"t";i:1514808000;s:1:"c";i:928146;}i:9;a:2:{s:1:"t";i:1514811600;s:1:"c";i:1137017;}i:10;a:2:{s:1:"t";i:1514815200;s:1:"c";i:1021557;}i:11;a:2:{s:1:"t";i:1514818800;s:1:"c";i:829979;}i:12;a:2:{s:1:"t";i:1514822400;s:1:"c";i:900106;}i:13;a:2:{s:1:"t";i:1514826000;s:1:"c";i:979868;}i:14;a:2:{s:1:"t";i:1514829600;s:1:"c";i:1029914;}i:15;a:2:{s:1:"t";i:1514833200;s:1:"c";i:931310;}i:16;a:2:{s:1:"t";i:1514836800;s:1:"c";i:904545;}i:17;a:2:{s:1:"t";i:1514840400;s:1:"c";i:915384;}i:18;a:2:{s:1:"t";i:1514844000;s:1:"c";i:930504;}i:19;a:2:{s:1:"t";i:1514847600;s:1:"c";i:1234461;}i:20;a:2:{s:1:"t";i:1514851200;s:1:"c";i:828595;}i:21;a:2:{s:1:"t";i:1514854800;s:1:"c";i:819261;}i:22;a:2:{s:1:"t";i:1514858400;s:1:"c";i:814347;}i:23;a:2:{s:1:"t";i:1514862000;s:1:"c";i:733819;}}s:2:"7d";a:7:{i:0;a:2:{s:1:"t";i:1514246400;s:1:"c";i:25573271;}i:1;a:2:{s:1:"t";i:1514332800;s:1:"c";i:22668443;}i:2;a:2:{s:1:"t";i:1514419200;s:1:"c";i:23206007;}i:3;a:2:{s:1:"t";i:1514505600;s:1:"c";i:22584647;}i:4;a:2:{s:1:"t";i:1514592000;s:1:"c";i:18257387;}i:5;a:2:{s:1:"t";i:1514678400;s:1:"c";i:22528731;}i:6;a:2:{s:1:"t";i:1514764800;s:1:"c";i:21987584;}}s:3:"30d";a:30:{i:0;a:2:{s:1:"t";i:1512259200;s:1:"c";i:43460762;}i:1;a:2:{s:1:"t";i:1512345600;s:1:"c";i:41627960;}i:2;a:2:{s:1:"t";i:1512432000;s:1:"c";i:37845190;}i:3;a:2:{s:1:"t";i:1512518400;s:1:"c";i:28991625;}i:4;a:2:{s:1:"t";i:1512604800;s:1:"c";i:27401351;}i:5;a:2:{s:1:"t";i:1512691200;s:1:"c";i:28746824;}i:6;a:2:{s:1:"t";i:1512777600;s:1:"c";i:29884490;}i:7;a:2:{s:1:"t";i:1512864000;s:1:"c";i:29747247;}i:8;a:2:{s:1:"t";i:1512950400;s:1:"c";i:34111953;}i:9;a:2:{s:1:"t";i:1513036800;s:1:"c";i:32361658;}i:10;a:2:{s:1:"t";i:1513123200;s:1:"c";i:31096487;}i:11;a:2:{s:1:"t";i:1513209600;s:1:"c";i:26287546;}i:12;a:2:{s:1:"t";i:1513296000;s:1:"c";i:23117919;}i:13;a:2:{s:1:"t";i:1513382400;s:1:"c";i:25791217;}i:14;a:2:{s:1:"t";i:1513468800;s:1:"c";i:24585350;}i:15;a:2:{s:1:"t";i:1513555200;s:1:"c";i:176146397;}i:16;a:2:{s:1:"t";i:1513641600;s:1:"c";i:88708942;}i:17;a:2:{s:1:"t";i:1513728000;s:1:"c";i:181849095;}i:18;a:2:{s:1:"t";i:1513814400;s:1:"c";i:30658714;}i:19;a:2:{s:1:"t";i:1513900800;s:1:"c";i:29772224;}i:20;a:2:{s:1:"t";i:1513987200;s:1:"c";i:27400454;}i:21;a:2:{s:1:"t";i:1514073600;s:1:"c";i:25534921;}i:22;a:2:{s:1:"t";i:1514160000;s:1:"c";i:28109357;}i:23;a:2:{s:1:"t";i:1514246400;s:1:"c";i:25573271;}i:24;a:2:{s:1:"t";i:1514332800;s:1:"c";i:22668443;}i:25;a:2:{s:1:"t";i:1514419200;s:1:"c";i:23206007;}i:26;a:2:{s:1:"t";i:1514505600;s:1:"c";i:22584647;}i:27;a:2:{s:1:"t";i:1514592000;s:1:"c";i:18257387;}i:28;a:2:{s:1:"t";i:1514678400;s:1:"c";i:22528731;}i:29;a:2:{s:1:"t";i:1514764800;s:1:"c";i:21987584;}}}s:9:"countries";a:1:{s:2:"7d";a:10:{i:0;a:2:{s:2:"cd";s:2:"RU";s:2:"ct";i:43642925;}i:1;a:2:{s:2:"cd";s:2:"CN";s:2:"ct";i:27995540;}i:2;a:2:{s:2:"cd";s:2:"US";s:2:"ct";i:13912252;}i:3;a:2:{s:2:"cd";s:2:"UA";s:2:"ct";i:12585406;}i:4;a:2:{s:2:"cd";s:2:"TR";s:2:"ct";i:9584742;}i:5;a:2:{s:2:"cd";s:2:"FR";s:2:"ct";i:5264921;}i:6;a:2:{s:2:"cd";s:2:"KR";s:2:"ct";i:2540691;}i:7;a:2:{s:2:"cd";s:2:"IN";s:2:"ct";i:1928110;}i:8;a:2:{s:2:"cd";s:2:"GB";s:2:"ct";i:1448143;}i:9;a:2:{s:2:"cd";s:2:"DE";s:2:"ct";i:1226796;}}}}', 'yes'),
('debugOn', '0', 'yes'),
('deleteTablesOnDeact', '0', 'yes'),
('detectProxyNextCheck', '1515473580', 'no'),
('detectProxyNonce', '79eb9abd9a42f097f71757fc752a94afbe7669ab8bc1a95f60c7dc89ddedad06', 'no'),
('detectProxyRecommendation', '', 'no'),
('disableCodeExecutionUploads', '0', 'yes'),
('disableConfigCaching', '0', 'yes'),
('disableCookies', '0', 'yes'),
('disableWAFIPBlocking', '0', 'yes'),
('email_summary_dashboard_widget_enabled', '1', 'yes'),
('email_summary_enabled', '1', 'yes'),
('email_summary_excluded_directories', 'wp-content/cache,wp-content/wflogs', 'yes'),
('email_summary_interval', 'weekly', 'yes'),
('encKey', '22be63ee6082dc9b', 'yes'),
('fileContentsGSB6315Migration', '1', 'yes'),
('firewallEnabled', '1', 'yes'),
('geoIPVersionHash', 'd3600d8a4dbbf3755acc9a41cdf6c0dac7e4466ecc2855f3cf78667893dc813f', 'yes'),
('hasKeyConflict', '', 'yes'),
('howGetIPs', '', 'yes'),
('howGetIPs_trusted_proxies', '', 'yes'),
('isPaid', '', 'yes'),
('lastBlockAggregation', '1514868780', 'yes'),
('lastDailyCron', '1514868784', 'yes'),
('lastDashboardCheck', '1514868784', 'yes'),
('lastScanCompleted', 'ok', 'yes'),
('lastScanFailureType', '', 'yes'),
('liveActivityPauseEnabled', '1', 'yes'),
('liveTrafficEnabled', '1', 'yes'),
('liveTraf_ignoreIPs', '', 'yes'),
('liveTraf_ignorePublishers', '1', 'yes'),
('liveTraf_ignoreUA', '', 'yes'),
('liveTraf_ignoreUsers', '', 'yes'),
('liveTraf_maxRows', '2000', 'yes'),
('loginSecurityEnabled', '1', 'yes'),
('loginSec_blockAdminReg', '1', 'yes'),
('loginSec_countFailMins', '240', 'yes'),
('loginSec_disableAuthorScan', '1', 'yes'),
('loginSec_disableOEmbedAuthor', '0', 'yes'),
('loginSec_enableSeparateTwoFactor', '0', 'yes'),
('loginSec_lockInvalidUsers', '0', 'yes'),
('loginSec_lockoutMins', '240', 'yes'),
('loginSec_maskLoginErrors', '1', 'yes'),
('loginSec_maxFailures', '20', 'yes'),
('loginSec_maxForgotPasswd', '20', 'yes'),
('loginSec_strongPasswds', 'pubs', 'yes'),
('loginSec_userBlacklist', '', 'yes'),
('lowResourceScansEnabled', '0', 'yes'),
('lowResourceScanWaitStep', '', 'yes'),
('max404Crawlers', 'DISABLED', 'yes'),
('max404Crawlers_action', 'throttle', 'yes'),
('max404Humans', 'DISABLED', 'yes'),
('max404Humans_action', 'throttle', 'yes'),
('maxExecutionTime', '', 'yes'),
('maxGlobalRequests', 'DISABLED', 'yes'),
('maxGlobalRequests_action', 'throttle', 'yes') ;
INSERT INTO `wp_wfConfig` ( `name`, `val`, `autoload`) VALUES
('maxMem', '256', 'yes'),
('maxRequestsCrawlers', 'DISABLED', 'yes'),
('maxRequestsCrawlers_action', 'throttle', 'yes'),
('maxRequestsHumans', 'DISABLED', 'yes'),
('maxRequestsHumans_action', 'throttle', 'yes'),
('maxScanHits', 'DISABLED', 'yes'),
('maxScanHits_action', 'throttle', 'yes'),
('migration636_email_summary_excluded_directories', '1', 'no'),
('neverBlockBG', 'neverBlockVerified', 'yes'),
('noc1ScanSchedule', 'a:3:{i:0;i:1514949000;i:1;i:1515208200;i:2;i:1515467400;}', 'yes'),
('notification_blogHighlights', '1', 'yes'),
('notification_productUpdates', '1', 'yes'),
('notification_promotions', '1', 'yes'),
('notification_scanStatus', '1', 'yes'),
('notification_securityAlerts', '1', 'yes'),
('notification_updatesNeeded', '1', 'yes'),
('other_blockBadPOST', '0', 'yes'),
('other_bypassLitespeedNoabort', '0', 'yes'),
('other_hideWPVersion', '0', 'yes'),
('other_noAnonMemberComments', '1', 'yes'),
('other_pwStrengthOnUpdate', '1', 'yes'),
('other_scanComments', '1', 'yes'),
('other_scanOutside', '0', 'yes'),
('other_WFNet', '1', 'yes'),
('scansEnabled_checkGSB', '1', 'yes'),
('scansEnabled_checkHowGetIPs', '1', 'yes'),
('scansEnabled_checkReadableConfig', '1', 'yes'),
('scansEnabled_comments', '1', 'yes'),
('scansEnabled_core', '1', 'yes'),
('scansEnabled_coreUnknown', '1', 'yes'),
('scansEnabled_diskSpace', '1', 'yes'),
('scansEnabled_dns', '1', 'yes'),
('scansEnabled_fileContents', '1', 'yes'),
('scansEnabled_fileContentsGSB', '1', 'yes'),
('scansEnabled_highSense', '0', 'yes'),
('scansEnabled_malware', '1', 'yes'),
('scansEnabled_oldVersions', '1', 'yes'),
('scansEnabled_options', '1', 'yes'),
('scansEnabled_passwds', '1', 'yes'),
('scansEnabled_plugins', '0', 'yes'),
('scansEnabled_posts', '1', 'yes'),
('scansEnabled_scanImages', '0', 'yes'),
('scansEnabled_suspectedFiles', '1', 'yes'),
('scansEnabled_suspiciousAdminUsers', '1', 'yes'),
('scansEnabled_suspiciousOptions', '1', 'yes'),
('scansEnabled_themes', '0', 'yes'),
('scansEnabled_wpscan_directoryListingEnabled', '1', 'yes'),
('scansEnabled_wpscan_fullPathDisclosure', '1', 'yes'),
('scan_exclude', '', 'yes'),
('scan_include_extra', '', 'yes'),
('scan_maxDuration', '', 'yes'),
('scan_maxIssues', '1000', 'yes'),
('scheduledScansEnabled', '1', 'yes'),
('showAdminBarMenu', '1', 'yes'),
('spamvertizeCheck', '0', 'yes'),
('ssl_verify', '1', 'yes'),
('startScansRemotely', '0', 'yes'),
('timeoffset_wf', '0', 'yes'),
('timeoffset_wf_updated', '1514868779', 'yes'),
('totalAlertsSent', '1', 'yes'),
('totalScansRun', '1', 'yes'),
('vulnerabilities_plugin', 'a:12:{i:0;a:4:{s:4:"slug";s:22:"advanced-custom-fields";s:11:"fromVersion";s:6:"4.4.12";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:1;a:4:{s:4:"slug";s:20:"enable-media-replace";s:11:"fromVersion";s:5:"3.1.1";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:2;a:4:{s:4:"slug";s:14:"login-lockdown";s:11:"fromVersion";s:6:"v1.7.1";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:3;a:4:{s:4:"slug";s:30:"quick-pagepost-redirect-plugin";s:11:"fromVersion";s:5:"5.1.8";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:4;a:4:{s:4:"slug";s:20:"simple-301-redirects";s:11:"fromVersion";s:4:"1.07";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:5;a:4:{s:4:"slug";s:40:"simple-301-redirects-addon-bulk-uploader";s:11:"fromVersion";s:6:"1.0.14";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:6;a:4:{s:4:"slug";s:20:"simple-page-ordering";s:11:"fromVersion";s:5:"2.2.4";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:7;a:4:{s:4:"slug";s:9:"wordfence";s:11:"fromVersion";s:6:"6.3.22";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:8;a:4:{s:4:"slug";s:16:"acf-options-page";s:11:"fromVersion";s:5:"2.0.1";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:9;a:4:{s:4:"slug";s:12:"acf-repeater";s:11:"fromVersion";s:5:"2.0.1";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:10;a:4:{s:4:"slug";s:12:"gravityforms";s:11:"fromVersion";s:5:"2.1.3";s:10:"vulnerable";b:0;s:4:"link";b:0;}i:11;a:4:{s:4:"slug";s:17:"wp-sync-db-master";s:11:"fromVersion";s:3:"1.5";s:10:"vulnerable";b:0;s:4:"link";b:0;}}', 'yes'),
('vulnRegex', '/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i', 'yes'),
('wafAlertInterval', '600', 'yes'),
('wafAlertOnAttacks', '1', 'yes'),
('wafAlertThreshold', '100', 'yes'),
('wafAlertWhitelist', '', 'yes'),
('welcomeClosed', '1', 'yes'),
('wfKillRequested', '0', 'no'),
('wfPeakMemory', '25165824', 'no'),
('wfScanStartVersion', '4.9.1', 'yes'),
('wfStatusStartMsgs', 'a:1:{i:0;s:0:"";}', 'yes'),
('wf_scanLastStatusTime', '0', 'yes'),
('wf_scanRunning', '', 'yes'),
('wf_summaryItems', 'a:9:{s:10:"totalUsers";i:1;s:10:"totalPages";s:1:"1";s:10:"totalPosts";s:1:"0";s:13:"totalComments";s:1:"0";s:15:"totalCategories";s:1:"1";s:11:"totalTables";i:40;s:9:"totalRows";i:371;s:8:"scanTime";d:1514868789.9993000030517578125;s:10:"lastUpdate";i:1514868789;}', 'yes'),
('whitelisted', '', 'yes'),
('wp_home_url', 'http://localhost', 'yes'),
('wp_site_url', 'http://localhost', 'yes') ;

#
# End of data contents of table `wp_wfConfig`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfCrawlers`
#

DROP TABLE IF EXISTS `wp_wfCrawlers`;


#
# Table structure of table `wp_wfCrawlers`
#

CREATE TABLE `wp_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfCrawlers`
#

#
# End of data contents of table `wp_wfCrawlers`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfFileMods`
#

DROP TABLE IF EXISTS `wp_wfFileMods`;


#
# Table structure of table `wp_wfFileMods`
#

CREATE TABLE `wp_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  `SHAC` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `stoppedOnSignature` varchar(255) NOT NULL DEFAULT '',
  `stoppedOnPosition` int(10) unsigned NOT NULL DEFAULT '0',
  `isSafeFile` varchar(1) NOT NULL DEFAULT '?',
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfFileMods`
#

#
# End of data contents of table `wp_wfFileMods`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfHits`
#

DROP TABLE IF EXISTS `wp_wfHits`;


#
# Table structure of table `wp_wfHits`
#

CREATE TABLE `wp_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attackLogTime` double(17,6) unsigned NOT NULL,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `statusCode` int(11) NOT NULL DEFAULT '200',
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  `action` varchar(64) NOT NULL DEFAULT '',
  `actionDescription` text,
  `actionData` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`),
  KEY `attackLogTime` (`attackLogTime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfHits`
#

#
# End of data contents of table `wp_wfHits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfHoover`
#

DROP TABLE IF EXISTS `wp_wfHoover`;


#
# Table structure of table `wp_wfHoover`
#

CREATE TABLE `wp_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` varbinary(124) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfHoover`
#

#
# End of data contents of table `wp_wfHoover`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfIssues`
#

DROP TABLE IF EXISTS `wp_wfIssues`;


#
# Table structure of table `wp_wfIssues`
#

CREATE TABLE `wp_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfIssues`
#

#
# End of data contents of table `wp_wfIssues`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfKnownFileList`
#

DROP TABLE IF EXISTS `wp_wfKnownFileList`;


#
# Table structure of table `wp_wfKnownFileList`
#

CREATE TABLE `wp_wfKnownFileList` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfKnownFileList`
#

#
# End of data contents of table `wp_wfKnownFileList`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfLeechers`
#

DROP TABLE IF EXISTS `wp_wfLeechers`;


#
# Table structure of table `wp_wfLeechers`
#

CREATE TABLE `wp_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfLeechers`
#

#
# End of data contents of table `wp_wfLeechers`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfLockedOut`
#

DROP TABLE IF EXISTS `wp_wfLockedOut`;


#
# Table structure of table `wp_wfLockedOut`
#

CREATE TABLE `wp_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfLockedOut`
#

#
# End of data contents of table `wp_wfLockedOut`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfLocs`
#

DROP TABLE IF EXISTS `wp_wfLocs`;


#
# Table structure of table `wp_wfLocs`
#

CREATE TABLE `wp_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfLocs`
#

#
# End of data contents of table `wp_wfLocs`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfLogins`
#

DROP TABLE IF EXISTS `wp_wfLogins`;


#
# Table structure of table `wp_wfLogins`
#

CREATE TABLE `wp_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hitID` int(11) DEFAULT NULL,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`),
  KEY `hitID` (`hitID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfLogins`
#

#
# End of data contents of table `wp_wfLogins`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfNet404s`
#

DROP TABLE IF EXISTS `wp_wfNet404s`;


#
# Table structure of table `wp_wfNet404s`
#

CREATE TABLE `wp_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfNet404s`
#

#
# End of data contents of table `wp_wfNet404s`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfNotifications`
#

DROP TABLE IF EXISTS `wp_wfNotifications`;


#
# Table structure of table `wp_wfNotifications`
#

CREATE TABLE `wp_wfNotifications` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `new` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `category` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '1000',
  `ctime` int(10) unsigned NOT NULL,
  `html` text NOT NULL,
  `links` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfNotifications`
#

#
# End of data contents of table `wp_wfNotifications`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfPendingIssues`
#

DROP TABLE IF EXISTS `wp_wfPendingIssues`;


#
# Table structure of table `wp_wfPendingIssues`
#

CREATE TABLE `wp_wfPendingIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfPendingIssues`
#

#
# End of data contents of table `wp_wfPendingIssues`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfReverseCache`
#

DROP TABLE IF EXISTS `wp_wfReverseCache`;


#
# Table structure of table `wp_wfReverseCache`
#

CREATE TABLE `wp_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfReverseCache`
#

#
# End of data contents of table `wp_wfReverseCache`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfSNIPCache`
#

DROP TABLE IF EXISTS `wp_wfSNIPCache`;


#
# Table structure of table `wp_wfSNIPCache`
#

CREATE TABLE `wp_wfSNIPCache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `IP` varchar(45) NOT NULL DEFAULT '',
  `expiration` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `body` varchar(255) NOT NULL DEFAULT '',
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `expiration` (`expiration`),
  KEY `IP` (`IP`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfSNIPCache`
#

#
# End of data contents of table `wp_wfSNIPCache`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfScanners`
#

DROP TABLE IF EXISTS `wp_wfScanners`;


#
# Table structure of table `wp_wfScanners`
#

CREATE TABLE `wp_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wfScanners`
#

#
# End of data contents of table `wp_wfScanners`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfStatus`
#

DROP TABLE IF EXISTS `wp_wfStatus`;


#
# Table structure of table `wp_wfStatus`
#

CREATE TABLE `wp_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfStatus`
#
INSERT INTO `wp_wfStatus` ( `id`, `ctime`, `level`, `type`, `msg`) VALUES
(1, '1514868789.949002', 10, 'info', 'SUM_PREP:Preparing a new scan.'),
(2, '1514868789.949946', 1, 'info', 'Initiating quick scan'),
(3, '1514868789.953882', 10, 'info', 'SUM_START:Scanning for old themes, plugins and core files'),
(4, '1514868789.974350', 10, 'info', 'SUM_ENDOK:Scanning for old themes, plugins and core files'),
(5, '1514868789.996709', 1, 'info', '-------------------'),
(6, '1514868789.997229', 1, 'info', 'Quick Scan Complete. Scanned in less than 1 second.'),
(7, '1514868789.997618', 10, 'info', 'SUM_FINAL:Scan complete. Congratulations, no new problems found.'),
(8, '1514868790.013511', 2, 'info', 'Wordfence used 0 B of memory for scan. Server peak memory usage was: 24 MB') ;

#
# End of data contents of table `wp_wfStatus`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfThrottleLog`
#

DROP TABLE IF EXISTS `wp_wfThrottleLog`;


#
# Table structure of table `wp_wfThrottleLog`
#

CREATE TABLE `wp_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfThrottleLog`
#

#
# End of data contents of table `wp_wfThrottleLog`
# --------------------------------------------------------



#
# Delete any existing table `wp_wfVulnScanners`
#

DROP TABLE IF EXISTS `wp_wfVulnScanners`;


#
# Table structure of table `wp_wfVulnScanners`
#

CREATE TABLE `wp_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wfVulnScanners`
#

#
# End of data contents of table `wp_wfVulnScanners`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpeditor_settings`
#

DROP TABLE IF EXISTS `wp_wpeditor_settings`;


#
# Table structure of table `wp_wpeditor_settings`
#

CREATE TABLE `wp_wpeditor_settings` (
  `key` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpeditor_settings`
#
INSERT INTO `wp_wpeditor_settings` ( `key`, `value`) VALUES
('admin_page_roles', 'a:3:{s:8:"settings";s:14:"manage_options";s:12:"theme-editor";s:11:"edit_themes";s:13:"plugin-editor";s:12:"edit_plugins";}'),
('enable_plugin_active_line', '1'),
('enable_plugin_line_numbers', '1'),
('enable_plugin_line_wrapping', '1'),
('enable_post_active_line', '1'),
('enable_post_editor', '1'),
('enable_post_line_numbers', '1'),
('enable_post_line_wrapping', '1'),
('enable_theme_active_line', '1'),
('enable_theme_line_numbers', '1'),
('enable_theme_line_wrapping', '1'),
('hide_default_plugin_editor', '1'),
('hide_default_theme_editor', '1'),
('plugin_editor_allowed_extensions', 'php~js~css~txt~htm~html~jpg~jpeg~png~gif~sql~po~less~xml'),
('plugin_file_upload', '1'),
('plugin_indent_unit', '2'),
('post_indent_unit', '2'),
('replace_plugin_edit_links', '1'),
('theme_editor_allowed_extensions', 'php~js~css~txt~htm~html~jpg~jpeg~png~gif~sql~po~less~xml'),
('theme_file_upload', '1'),
('theme_indent_unit', '2'),
('upgrade', '1'),
('version', '1.2.6.3') ;

#
# End of data contents of table `wp_wpeditor_settings`
# --------------------------------------------------------

#
# Add constraints back in
#

